# MDView Static Build

This is the production build of MDView - a self-contained markdown viewer.

## Quick Start

Simply open `index.html` in any web browser! No server required.

## Features

- ✅ Drag & Drop markdown files
- ✅ File picker upload
- ✅ GitHub Flavored Markdown rendering
- ✅ Responsive design
- ✅ Works completely offline
- ✅ No installation needed

## File Structure

- `index.html` - Main application (open this in your browser)
- `static/css/main.08e0858e.css` - Styles
- `static/js/main.3afb8414.js` - Application code

## Browser Compatibility

Works in all modern browsers:
- Chrome
- Firefox
- Safari
- Edge

---

*Built with React and Create React App*
